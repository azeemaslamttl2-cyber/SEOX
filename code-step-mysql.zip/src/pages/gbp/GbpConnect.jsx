import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import {
  AlertCircle,
  AlertTriangle,
  BadgeCheck,
  Building2,
  Check,
  ExternalLink,
  Loader2,
  MapPin,
  Plug,
  RefreshCw,
  Star,
  Trash2,
  Unplug,
} from 'lucide-react';
import { useProjectSelection } from '../../context/CrawlContext.jsx';
import {
  invalidateGbpConnection,
  readGbpAttachedLocations,
  readGbpConnectionStatus,
} from '../../lib/gbpCache.js';
import {
  attachLocations,
  detachLocation,
  disconnectGbp,
  getGbpAuthUrl,
  listGbpAccounts,
  listGoogleLocations,
  resyncLocations,
  selectGbpAccount,
  setPrimaryLocation,
} from '../../lib/gbpApi.js';

const card = 'rounded-2xl border border-white/10 bg-white/[0.02] p-5';

/** e.g. "16 Sep 2026 16:45" — the format the connection card reads best in. */
function formatSyncedAt(value) {
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return '';
  return date.toLocaleString(undefined, {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

function VerificationBadge({ status }) {
  const map = {
    VERIFIED: { label: 'Verified', className: 'bg-emerald-500/15 text-emerald-300', Icon: BadgeCheck },
    UNVERIFIED: { label: 'Unverified', className: 'bg-rose-500/15 text-rose-300', Icon: AlertTriangle },
    UNKNOWN: { label: 'Unknown', className: 'bg-white/[0.06] text-white/50', Icon: AlertCircle },
  };
  const { label, className, Icon } = map[status] || map.UNKNOWN;
  return (
    <span className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-semibold ${className}`}>
      <Icon className="h-3 w-3" />
      {label}
    </span>
  );
}

function Notice({ tone = 'info', title, children }) {
  const tones = {
    info: 'border-teal-500/25 bg-teal-500/[0.06] text-teal-200',
    warn: 'border-amber-500/25 bg-amber-500/[0.06] text-amber-200',
    error: 'border-rose-500/25 bg-rose-500/[0.06] text-rose-200',
  };
  return (
    <div className={`rounded-xl border p-4 text-sm ${tones[tone]}`}>
      {title ? <p className="font-semibold">{title}</p> : null}
      <div className="mt-1 leading-relaxed text-white/60">{children}</div>
    </div>
  );
}

export default function GbpConnect() {
  const { project, storageReady } = useProjectSelection();
  const navigate = useNavigate();
  const [params, setParams] = useSearchParams();
  const projectId = project?.id || '';

  const [status, setStatus] = useState(null);
  const [accounts, setAccounts] = useState([]);
  const [accountsError, setAccountsError] = useState('');
  const [accountsStale, setAccountsStale] = useState(false);
  // 'database' or 'google' — shown so it is clear the page is not re-querying
  // Google on every visit.
  const [dataSource, setDataSource] = useState('database');
  const [quotaBlocked, setQuotaBlocked] = useState(false);
  const [neverSynced, setNeverSynced] = useState(false);
  const [syncedAt, setSyncedAt] = useState(null);
  const [attached, setAttached] = useState([]);
  const [available, setAvailable] = useState(null);
  const [selection, setSelection] = useState(() => new Set());

  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState('');
  const [error, setError] = useState('');
  // Which account the picker was already opened for, so the effect below stays
  // a one-shot per account rather than a quota-burning loop.
  const autoBrowsedRef = useRef('');

  const noAccounts = params.get('noAccounts') === '1';
  // Set by the OAuth callback only, so a live fetch happens on the return from
  // Google and never on a plain page load.
  const justConnected = params.get('next') || '';

  // `force` is used after a mutation, where the cached copy is known stale.
  // `refreshAccounts` is the only thing here that can reach Google. Everything
  // else - the connection, the attached profiles - is read from the database,
  // so an ordinary page load spends no Business Profile quota at all.
  const loadStatus = useCallback(async ({ force = false, refreshAccounts = false } = {}) => {
    if (!projectId) {
      setLoading(false);
      return;
    }
    setError('');
    try {
      const next = await readGbpConnectionStatus(projectId, { force });
      setStatus(next);
      if (next.connected) {
        const [accountData, attachedData] = await Promise.all([
          listGbpAccounts(projectId, { refresh: refreshAccounts }).catch((err) => ({
            accounts: [],
            error: err.message,
          })),
          readGbpAttachedLocations(projectId, { force }).catch(() => ({ locations: [] })),
        ]);
        setAccounts(accountData.accounts || []);
        // listGbpAccounts failing is not the same as Google reporting zero
        // profiles, but both arrive here as an empty array. Keeping the message
        // lets the UI tell the two apart instead of blaming the user's access.
        // `quotaError` is the same distinction made server-side: the list is the
        // stored copy and Google is currently refusing to confirm it.
        setAccountsError(accountData.error || accountData.quotaError || '');
        setAccountsStale(Boolean(accountData.quotaError));
        setQuotaBlocked(Boolean(accountData.quotaBlocked));
        setNeverSynced(Boolean(accountData.neverSynced));
        setSyncedAt(accountData.syncedAt || null);
        setDataSource(accountData.dataSource || 'database');
        setAttached(attachedData.locations || []);
      } else {
        setAccounts([]);
        setAccountsError('');
        setAccountsStale(false);
        setQuotaBlocked(false);
        setNeverSynced(false);
        setSyncedAt(null);
        setAttached([]);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [projectId]);

  useEffect(() => {
    setLoading(true);
    setAvailable(null);
    autoBrowsedRef.current = '';
    // The callback navigates here in-app, so the cached status is the one from
    // before the connection. Returning from Google always re-reads - from our
    // own database, which is where the exchange just saved everything.
    loadStatus({ force: Boolean(justConnected) });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loadStatus]);

  const run = useCallback(
    async (key, task) => {
      setBusy(key);
      setError('');
      try {
        await task();
      } catch (err) {
        setError(err.message);
      } finally {
        setBusy('');
      }
    },
    []
  );

  const handleConnect = () =>
    run('connect', async () => {
      const authUrl = await getGbpAuthUrl(projectId, '/local-seo/gbp');
      window.location.assign(authUrl);
    });

  const handleDisconnect = () =>
    run('disconnect', async () => {
      await disconnectGbp(projectId);
      setParams({});
      setAvailable(null);
      // The server drops the connection, its locations and its cached accounts;
      // this clears the browser's copies so a reconnect starts from nothing and
      // reads the next Google account fresh.
      autoBrowsedRef.current = '';
      setDataSource('database');
      invalidateGbpConnection(projectId);
      await loadStatus({ force: true });
    });

  const handleSelectAccount = (account) =>
    run(`account:${account.accountId}`, async () => {
      await selectGbpAccount(projectId, account);
      setAvailable(null);
      invalidateGbpConnection(projectId);
      await loadStatus({ force: true });
    });

  const handleLoadLocations = useCallback(
    () =>
      run('locations', async () => {
        const data = await listGoogleLocations(projectId);
        setAvailable(data.locations || []);
        setSelection(new Set());
      }),
    [projectId, run]
  );

  // Land on the profile picker instead of an empty panel - but only on the way
  // back from Google.
  //
  // `next=select-location` is the server saying this consent found several
  // profiles and needs a choice, so fetching the list is what the user is
  // waiting for. On an ordinary visit nothing is fetched: the page renders from
  // the database, and a live list costs a request against a Business Profile
  // quota that is measured per minute. The ref keys on the account so even that
  // one case is a single call per mount.
  useEffect(() => {
    if (justConnected !== 'select-location') return;
    if (!status?.connected || !status.accountId) return;
    if (attached.length > 0 || available || busy) return;
    if (autoBrowsedRef.current === status.accountId) return;

    autoBrowsedRef.current = status.accountId;
    handleLoadLocations();
    // Consume the marker, so reloading this URL does not spend another live
    // request. Re-runs the effect once with an empty `justConnected`, which the
    // guard above returns on immediately.
    setParams({}, { replace: true });
  }, [justConnected, status, attached, available, busy, handleLoadLocations, setParams]);

  const handleAttach = () =>
    run('attach', async () => {
      const result = await attachLocations(projectId, [...selection]);
      setSelection(new Set());
      setAvailable(null);
      invalidateGbpConnection(projectId);
      await loadStatus({ force: true });
      if (result.missing?.length) {
        setError(`Google no longer lists: ${result.missing.join(', ')}`);
      }
    });

  const handleResync = () =>
    run('resync', async () => {
      const result = await resyncLocations(projectId);
      invalidateGbpConnection(projectId);
      await loadStatus({ force: true });
      if (result.lost?.length) {
        setError(
          `These locations are attached in SEOX but no longer visible in the Google account: ${result.lost.join(', ')}`
        );
      }
    });

  const toggleSelection = (locationId) => {
    setSelection((previous) => {
      const next = new Set(previous);
      if (next.has(locationId)) next.delete(locationId);
      else next.add(locationId);
      return next;
    });
  };

  const selectedAccount = useMemo(
    () => accounts.find((account) => account.accountId === status?.accountId) || null,
    [accounts, status]
  );

  // The project arrives from CrawlContext asynchronously, so on a fresh page load
  // (a reload, or the return from Google with ?connected=1) projectId is empty for
  // a moment while hydration runs. Checking it before storageReady flashed the
  // "Select a project first" notice at someone who had a project selected all
  // along - and it reads as a dead end, not as "still loading".
  if (!storageReady || loading) {
    return (
      <div className={card}>
        <div className="flex items-center gap-2 text-sm text-white/60">
          <Loader2 className="h-4 w-4 animate-spin" />
          {storageReady ? 'Loading Business Profile connection…' : 'Loading project…'}
        </div>
      </div>
    );
  }

  if (!projectId) {
    return (
      <div className={card}>
        <Notice tone="warn" title="Select a project first">
          Business Profile connections are stored per project. Pick a project from the selector above,
          then connect the listing that belongs to it.
        </Notice>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="font-display text-xl font-bold">Google Business Profile</h1>
          <p className="mt-1 text-sm text-white/45">
            Connect the listing for <span className="text-white/70">{project?.name || project?.domain}</span> and
            attach the locations SEOX should manage.
          </p>
        </div>
        {status?.connected ? (
          <button
            onClick={handleDisconnect}
            disabled={busy === 'disconnect'}
            className="inline-flex items-center gap-2 rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2 text-sm font-semibold text-white/70 transition hover:bg-white/[0.08] disabled:opacity-50"
          >
            {busy === 'disconnect' ? <Loader2 className="h-4 w-4 animate-spin" /> : <Unplug className="h-4 w-4" />}
            Disconnect
          </button>
        ) : null}
      </div>

      {error ? <Notice tone="error" title="Something went wrong">{error}</Notice> : null}

      {status?.status === 'needs_reauth' ? (
        <Notice tone="warn" title="Authorisation expired">
          {status.statusDetail || 'Google revoked the stored access.'} Reconnect to resume syncing.
        </Notice>
      ) : null}

      {/* Step 1 — connect */}
      {!status?.connected ? (
        <div className={card}>
          <div className="flex items-start gap-4">
            <div className="rounded-xl bg-teal-500/10 p-3">
              <Plug className="h-5 w-5 text-teal-400" />
            </div>
            <div className="min-w-0 flex-1">
              <h2 className="font-semibold">Connect a Google account</h2>
              <p className="mt-1 text-sm leading-relaxed text-white/45">
                Sign in with the Google account that owns or manages the listing. API approval lets SEOX
                ask Google for the data — it does not grant access to a profile the signed-in account
                cannot already manage in Business Profile Manager.
              </p>
              <button
                onClick={handleConnect}
                disabled={busy === 'connect'}
                className="mt-4 inline-flex items-center gap-2 rounded-xl bg-brand-500 px-4 py-2 text-sm font-semibold text-white transition hover:bg-brand-600 disabled:opacity-50"
              >
                {busy === 'connect' ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plug className="h-4 w-4" />}
                Connect Google Business Profile
              </button>
            </div>
          </div>
        </div>
      ) : null}

      {/* Step 2 — pick the account */}
      {status?.connected ? (
        <div className={card}>
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h2 className="flex items-center gap-2 font-semibold">
              <Building2 className="h-4 w-4 text-teal-400" />
              Business Profile account
            </h2>
            <div className="flex flex-wrap items-center gap-3">
              <span className="text-xs text-white/40">
                Signed in as {status.googleEmail || 'unknown'}
                {accounts.length > 0 && dataSource === 'database'
                  ? ` · Showing last synchronized data${
                      syncedAt ? ` · Last synchronized: ${formatSyncedAt(syncedAt)}` : ''
                    }`
                  : dataSource === 'google'
                    ? ' · just synchronized from Google'
                    : ''}
              </span>
              <button
                onClick={() =>
                  run('refresh-accounts', async () => {
                    invalidateGbpConnection(projectId);
                    await loadStatus({ force: true, refreshAccounts: true });
                  })
                }
                disabled={busy === 'refresh-accounts'}
                title="Re-read the account list from Google"
                className="inline-flex items-center gap-1.5 rounded-lg border border-white/10 px-2.5 py-1 text-xs font-semibold text-white/60 transition hover:bg-white/[0.06] disabled:opacity-50"
              >
                {busy === 'refresh-accounts' ? (
                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                ) : (
                  <RefreshCw className="h-3.5 w-3.5" />
                )}
                Refresh from Google
              </button>
            </div>
          </div>

          {accountsError ? (
            <div className="mt-4">
              <Notice
                // A quota refusal with data to show is a warning, not an error:
                // the page still works, it just cannot refresh.
                tone={quotaBlocked && accounts.length > 0 ? 'warn' : 'error'}
                title={
                  quotaBlocked
                    ? accounts.length > 0
                      ? 'Showing last synchronized data'
                      : 'Google Business Profile is temporarily unavailable'
                    : 'Could not read the Business Profile accounts'
                }
              >
                {quotaBlocked ? null : (
                  <>
                    Google rejected the request, so this says nothing about what{' '}
                    <span className="text-white/80">{status.googleEmail}</span> manages.{' '}
                  </>
                )}
                {accountsError}
                {quotaBlocked && syncedAt ? (
                  <span className="mt-2 block text-xs text-white/45">
                    Last synchronized: {formatSyncedAt(syncedAt)}
                  </span>
                ) : null}
              </Notice>
            </div>
          ) : null}

          {/* Connected, but Google has never successfully answered for this
              project — so there is nothing stored to show. Offering the sync
              as a button keeps the call user-initiated instead of firing one
              on every page load. */}
          {!accountsError && neverSynced ? (
            <div className="mt-4">
              <Notice tone="info" title="No Business Profile data synchronized yet">
                SEOX has not yet read the Business Profile accounts for this project. Use{' '}
                <span className="text-white/80">Refresh from Google</span> above to synchronize —
                the page does not call Google on its own, to protect the shared API quota.
              </Notice>
            </div>
          ) : null}

          {!accountsError && !neverSynced && (noAccounts || accounts.length === 0) ? (
            <div className="mt-4">
              <Notice tone="warn" title="This Google account manages no Business Profiles">
                Ask the client to add <span className="text-white/80">{status.googleEmail}</span> as a
                manager on the listing, then reload this page.{' '}
                <a
                  href="https://business.google.com/"
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1 text-teal-300 hover:underline"
                >
                  Business Profile Manager <ExternalLink className="h-3 w-3" />
                </a>
              </Notice>
            </div>
          ) : accounts.length > 0 ? (
            <ul className="mt-4 space-y-2">
              {accounts.map((account) => {
                const isSelected = account.accountId === status.accountId;
                return (
                  <li key={account.accountId}>
                    <button
                      onClick={() => handleSelectAccount(account)}
                      disabled={busy === `account:${account.accountId}`}
                      className={`flex w-full items-center justify-between gap-3 rounded-xl border px-4 py-3 text-left transition ${
                        isSelected
                          ? 'border-teal-500/40 bg-teal-500/[0.08]'
                          : 'border-white/10 bg-white/[0.02] hover:bg-white/[0.05]'
                      }`}
                    >
                      <div className="min-w-0">
                        <p className="truncate text-sm font-semibold">{account.accountName}</p>
                        <p className="truncate text-xs text-white/40">
                          {account.accountId}
                          {account.accountType ? ` · ${account.accountType}` : ''}
                          {account.role ? ` · ${account.role}` : ''}
                        </p>
                      </div>
                      {busy === `account:${account.accountId}` ? (
                        <Loader2 className="h-4 w-4 shrink-0 animate-spin text-white/40" />
                      ) : isSelected ? (
                        <Check className="h-4 w-4 shrink-0 text-teal-400" />
                      ) : null}
                    </button>
                  </li>
                );
              })}
            </ul>
          ) : null}
        </div>
      ) : null}

      {/* Step 3 — attach locations */}
      {status?.connected && status.accountId ? (
        <div className={card}>
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h2 className="flex items-center gap-2 font-semibold">
              <MapPin className="h-4 w-4 text-teal-400" />
              Attached locations
              <span className="rounded-full bg-white/[0.06] px-2 py-0.5 text-[11px] text-white/50">
                {attached.length}
              </span>
            </h2>
            <div className="flex gap-2">
              {attached.length > 0 ? (
                <button
                  onClick={handleResync}
                  disabled={busy === 'resync'}
                  className="inline-flex items-center gap-2 rounded-lg border border-white/10 px-3 py-1.5 text-xs font-semibold text-white/60 transition hover:bg-white/[0.06] disabled:opacity-50"
                >
                  {busy === 'resync' ? (
                    <Loader2 className="h-3.5 w-3.5 animate-spin" />
                  ) : (
                    <RefreshCw className="h-3.5 w-3.5" />
                  )}
                  Resync from Google
                </button>
              ) : null}
              <button
                onClick={handleLoadLocations}
                disabled={busy === 'locations'}
                className="inline-flex items-center gap-2 rounded-lg bg-white/[0.06] px-3 py-1.5 text-xs font-semibold text-white/80 transition hover:bg-white/[0.1] disabled:opacity-50"
              >
                {busy === 'locations' ? (
                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                ) : (
                  <Building2 className="h-3.5 w-3.5" />
                )}
                {/* Same call either way; the label names what the click is for
                    at this point in the flow, so switching profile later does
                    not look like it needs a fresh project. */}
                {attached.length > 0 ? 'Change Business Profile' : 'Browse Google locations'}
              </button>
            </div>
          </div>

          {attached.length === 0 && !available ? (
            <p className="mt-4 text-sm text-white/40">
              No locations attached yet. Browse the account to pick the listings this project should manage.
            </p>
          ) : null}

          {attached.length > 0 ? (
            <ul className="mt-4 divide-y divide-white/[0.06]">
              {attached.map((location) => (
                <li key={location.id} className="flex flex-wrap items-center gap-3 py-3">
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="truncate text-sm font-semibold">{location.businessName}</p>
                      <VerificationBadge status={location.verificationStatus} />
                      {location.isPrimary ? (
                        <span className="inline-flex items-center gap-1 rounded-full bg-brand-500/15 px-2 py-0.5 text-[11px] font-semibold text-brand-300">
                          <Star className="h-3 w-3" /> Primary
                        </span>
                      ) : null}
                      {location.hasGoogleUpdates ? (
                        <span className="rounded-full bg-amber-500/15 px-2 py-0.5 text-[11px] font-semibold text-amber-300">
                          Google update pending
                        </span>
                      ) : null}
                    </div>
                    <p className="mt-0.5 truncate text-xs text-white/40">
                      {[location.primaryCategory, location.address].filter(Boolean).join(' · ') ||
                        location.locationId}
                    </p>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => navigate(`/local-seo/gbp/overview?location=${location.id}`)}
                      className="rounded-lg bg-white/[0.06] px-3 py-1.5 text-xs font-semibold text-white/75 transition hover:bg-white/[0.1]"
                    >
                      Open dashboard
                    </button>
                    {!location.isPrimary ? (
                      <button
                        title="Make primary"
                        onClick={() =>
                          run(`primary:${location.id}`, async () => {
                            await setPrimaryLocation(projectId, location.id);
                            invalidateGbpConnection(projectId);
      await loadStatus({ force: true });
                          })
                        }
                        className="rounded-lg p-1.5 text-white/40 transition hover:bg-white/[0.06] hover:text-brand-300"
                      >
                        <Star className="h-4 w-4" />
                      </button>
                    ) : null}
                    <button
                      title="Detach"
                      onClick={() =>
                        run(`detach:${location.id}`, async () => {
                          await detachLocation(projectId, location.id);
                          invalidateGbpConnection(projectId);
      await loadStatus({ force: true });
                        })
                      }
                      className="rounded-lg p-1.5 text-white/40 transition hover:bg-rose-500/10 hover:text-rose-300"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </li>
              ))}
            </ul>
          ) : null}

          {available ? (
            <div className="mt-5 rounded-xl border border-white/10 bg-white/[0.02] p-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <p className="text-sm font-semibold">
                  {available.length === 0
                    ? `No Business Profiles in ${selectedAccount?.accountName || 'this account'}`
                    : `Select a Business Profile — ${available.length} in ${
                        selectedAccount?.accountName || 'this account'
                      }`}
                </p>
                <button
                  onClick={handleAttach}
                  disabled={selection.size === 0 || busy === 'attach'}
                  className="inline-flex items-center gap-2 rounded-lg bg-brand-500 px-3 py-1.5 text-xs font-semibold text-white transition hover:bg-brand-600 disabled:opacity-40"
                >
                  {busy === 'attach' ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : null}
                  Attach {selection.size || ''} selected
                </button>
              </div>

              {available.length === 0 ? (
                <p className="mt-3 text-sm leading-relaxed text-white/45">
                  No accessible Google Business Profile was found for this Google account. The account
                  is signed in and the permission was granted, but it does not manage any listing in{' '}
                  {selectedAccount?.accountName || 'this account'} — ask the owner to add{' '}
                  <span className="text-white/70">{status.googleEmail}</span> as a manager, then use
                  Change Business Profile to look again.
                </p>
              ) : null}

              <ul className="mt-3 max-h-80 space-y-1.5 overflow-y-auto no-scrollbar">
                {available.map((location) => (
                  <li key={location.locationId}>
                    <label
                      className={`flex cursor-pointer items-center gap-3 rounded-lg border px-3 py-2.5 transition ${
                        location.attached
                          ? 'border-white/[0.06] bg-white/[0.01] opacity-50'
                          : 'border-white/10 bg-white/[0.02] hover:bg-white/[0.05]'
                      }`}
                    >
                      <input
                        type="checkbox"
                        disabled={location.attached}
                        checked={selection.has(location.locationId)}
                        onChange={() => toggleSelection(location.locationId)}
                        className="h-4 w-4 accent-brand-500"
                      />
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="truncate text-sm">{location.businessName}</span>
                          <VerificationBadge status={location.verificationStatus} />
                          {location.attached ? (
                            <span className="text-[11px] text-white/35">already attached</span>
                          ) : null}
                        </div>
                        <p className="truncate text-xs text-white/35">
                          {[location.storeCode, location.primaryCategory, location.address]
                            .filter(Boolean)
                            .join(' · ')}
                        </p>
                      </div>
                    </label>
                  </li>
                ))}
              </ul>
            </div>
          ) : null}
        </div>
      ) : null}

      {status?.lastSync ? (
        <p className="text-xs text-white/30">
          Last sync: {status.lastSync.type} · {status.lastSync.status} ·{' '}
          {new Date(status.lastSync.at).toLocaleString()}
          {status.lastSync.message ? ` · ${status.lastSync.message}` : ''}
        </p>
      ) : null}
    </div>
  );
}
