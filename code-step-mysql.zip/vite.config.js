import { defineConfig, loadEnv } from "vite";
import react from "@vitejs/plugin-react";
import fs from "node:fs";
import { onRequest as autocompleteOnRequest } from "./functions/api/autocomplete.js";
import { onRequest as gscTokenOnRequest } from "./functions/api/gsc-token.js";
import { onRequest as gbpConnectOnRequest } from "./functions/api/gbp/connect.js";
import { onRequest as gbpAccountsOnRequest } from "./functions/api/gbp/accounts.js";
import { onRequest as gbpLocationsOnRequest } from "./functions/api/gbp/locations.js";
import { onRequest as gbpOverviewOnRequest } from "./functions/api/gbp/overview.js";
import { onRequest as gbpProfileOnRequest } from "./functions/api/gbp/profile.js";
import { onRequest as gbpAuditOnRequest } from "./functions/api/gbp/audit.js";
import { onRequest as gbpPostsOnRequest } from "./functions/api/gbp/posts.js";
import { onRequest as gbpAutomationOnRequest } from "./functions/api/gbp/automation.js";
import { onRequest as gbpJobsOnRequest } from "./functions/api/gbp/jobs.js";
import { onRequest as gbpReviewsOnRequest } from "./functions/api/gbp/reviews.js";
import { onRequest as gbpInsightsOnRequest } from "./functions/api/gbp/insights.js";
import { onRequest as gbpQandaOnRequest } from "./functions/api/gbp/qanda.js";
import { onRequest as gbpRecommendationsOnRequest } from "./functions/api/gbp/recommendations.js";
import { onRequest as gbpHistoryOnRequest } from "./functions/api/gbp/history.js";
import { onRequest as jiraConnectOnRequest } from "./functions/api/jira/connect.js";
import { onRequest as jiraStatusOnRequest } from "./functions/api/jira/status.js";
import { onRequest as jiraMetadataOnRequest } from "./functions/api/jira/metadata.js";
import { onRequest as jiraMappingOnRequest } from "./functions/api/jira/mapping.js";
import { onRequest as jiraIssuesOnRequest } from "./functions/api/jira/issues.js";
import { onRequest as jiraIssueStatusOnRequest } from "./functions/api/jira/issues/status.js";
import { onRequest as jiraWebhookOnRequest } from "./functions/api/jira/webhook.js";
import { onRequest as jiraJobsOnRequest } from "./functions/api/jira/jobs.js";
import { onRequest as wordpressSecurityOnRequest } from "./functions/api/tech-seo/wordpress-security.js";
import { onRequest as deepseekSettingsOnRequest } from "./functions/api/deepseek-settings.js";
import { onRequest as pagespeedOnRequest } from "./functions/api/pagespeed.js";
import { onRequest as speedOnRequest } from "./functions/api/tech-seo/speed.js";
import { onRequest as screamingFrogOnRequest } from "./functions/api/tech-seo/screaming-frog.js";
import { onRequest as screamingFrogReportDownloadOnRequest } from "./functions/api/tech-seo/screaming-frog/report-download.js";
import { onRequest as screamingFrogUrlReportsOnRequest } from "./functions/api/tech-seo/screaming-frog/url-reports.js";
import { onRequest as projectsOnRequest } from "./functions/api/projects.js";
import { onRequest as generalSettingsOnRequest } from "./functions/api/settings/general.js";
import { onRequest as publicSettingsOnRequest } from "./functions/api/settings/public.js";
import { onRequest as projectDetailsOnRequest } from "./functions/api/project-details.js";
import { onRequest as backlinksAnalyzeOnRequest } from "./functions/api/tech-seo/backlinks/analyze.js";
import { onRequest as w3cValidateOnRequest } from "./functions/api/tech-seo/w3c/validate.js";
import { onRequest as adminW3cValidateOnRequest } from "./functions/api/tech-seo/w3c/admin-validation.js";
import { onRequest as expiredDomainsCheckOnRequest } from "./functions/api/off-page/expired-domains/check.js";
import { onRequest as backlinkCleanerOnRequest } from "./functions/api/off-page/backlink-cleaner.js";
import { onRequest as backlinkIndexerOnRequest } from "./functions/api/off-page/backlink-indexer.js";
import { onRequest as keywordResearchOnRequest } from "./functions/api/keywords/research.js";
import { onRequest as ubersuggestOnRequest } from "./functions/api/keywords/ubersuggest.js";
import { onRequest as contentOutlineOnRequest } from "./functions/api/content/outline.js";
import { onRequest as aiHelperOnRequest } from "./functions/api/content/ai-helper.js";
import { onRequest as entitiesExtractorOnRequest } from "./functions/api/content/entities-extractor.js";
import { onRequest as entitiesGeneratorOnRequest } from "./functions/api/content/entities-generator.js";
import { onRequest as contentNgramsOnRequest } from "./functions/api/content/ngrams.js";
import { onRequest as contentNlpOnRequest } from "./functions/api/content/nlp.js";
import { onRequest as contentGrammarOnRequest } from "./functions/api/content/grammar.js";
import { onRequest as contentUniqueNgramsOnRequest } from "./functions/api/content/unique-ngrams.js";
import { onRequest as contentSkipGramOnRequest } from "./functions/api/content/skip-gram.js";
import { onRequest as contentOptimizationOnRequest } from "./functions/api/content/optimization.js";
import { onRequest as contentWatermarkRemoverOnRequest } from "./functions/api/content/watermark-remover.js";
import { onRequest as contentSemanticGeneratorOnRequest } from "./functions/api/content/semantic-generator.js";
import { onRequest as contentAnalyzerOnRequest } from "./functions/api/content/content-analyzer.js";
import { onRequest as textEditorOnRequest } from "./functions/api/seo-tools/text-editor.js";
import { onRequest as domainSeparatorOnRequest } from "./functions/api/seo-tools/domain-separator.js";
import { onRequest as wordCounterOnRequest } from "./functions/api/seo-tools/word-counter.js";
import { onRequest as botViewerOnRequest } from "./functions/api/seo-tools/bot-viewer.js";
import { onRequest as daPaCheckerOnRequest } from "./functions/api/seo-tools/da-pa-checker.js";
import { onRequest as metaExtractorOnRequest } from "./functions/api/seo-tools/meta-extractor.js";
import { onRequest as sitemapExtractorOnRequest } from "./functions/api/seo-tools/sitemap-extractor.js";
import { onRequest as seoToolsOnRequest } from "./functions/api/seo-tools.js";
import { onRequest as promptTrackingOnRequest } from "./functions/api/geo/prompt-tracking.js";
import { onRequest as brandSentimentOnRequest } from "./functions/api/geo/brand-sentiment.js";
import { onRequest as citationFlowOnRequest } from "./functions/api/geo/citation-flow.js";
import { onRequest as competitorResearchOnRequest } from "./functions/api/geo/competitor-research.js";
import { onRequest as internalLinksOnRequest } from "./functions/api/geo/internal-links.js";
import { onRequest as aiChatOnRequest } from "./functions/api/geo/ai-chat.js";
import { onRequest as llmsGeneratorOnRequest } from "./functions/api/geo/llms-generator.js";
import { onRequest as aiModelCheckerOnRequest } from "./functions/api/geo/ai-model-checker.js";
import { onRequest as aiCompatibilityOnRequest } from "./functions/api/geo/ai-compatibility.js";
import { onRequest as semanticWriterEditorOnRequest } from "./functions/api/content/semantic-writer/editor.js";
import { onRequest as contentWriterOnRequest } from "./functions/api/content-writer.js";
import { onRequest as auditorOnRequest } from "./functions/api/auditor.js";
import { onRequestGet as authOnRequestGet, onRequestPost as authOnRequestPost } from "./functions/api/auth.js";
import fetchUrlMetaHandler from "./functions/_handlers/fetch-url-meta.js";
import webmasterApiHandler from "./functions/_handlers/webmaster-api.js";
import { verifyFirebaseIdToken } from "./functions/_lib/firebase-rest.js";
import { runNodeHandler } from "./functions/_lib/node-handler-adapter.js";
import proxyHandler from "./functions/_handlers/proxy.js";
import { fetchPublicHttpUrl, parsePublicHttpUrl } from "./functions/_lib/url-security.js";

const TEXT_TYPES = [
  "text/",
  "application/json",
  "application/javascript",
  "application/xml",
  "application/xhtml+xml",
  "application/rss+xml",
  "application/atom+xml",
  "image/svg+xml",
];

async function verifyDevApiRequest(req) {
  const headers = new Headers();
  const authorization = req.headers.authorization || req.headers.Authorization;
  if (authorization) headers.set("authorization", authorization);
  return verifyFirebaseIdToken(
    new Request("http://127.0.0.1/auth", { headers }),
    loadDevApiEnv()
  );
}

function parseEnvFile(pathname) {
  if (!fs.existsSync(pathname)) return {};

  return Object.fromEntries(
    fs
      .readFileSync(pathname, "utf8")
      .split(/\r?\n/)
      .map((line) => line.trim())
      .filter((line) => line && !line.startsWith("#") && line.includes("="))
      .map((line) => {
        const separator = line.indexOf("=");
        const key = line.slice(0, separator).trim();
        let value = line.slice(separator + 1).trim();
        if (
          (value.startsWith('"') && value.endsWith('"')) ||
          (value.startsWith("'") && value.endsWith("'"))
        ) {
          value = value.slice(1, -1);
        }
        return [key, value];
      })
  );
}

function loadDevApiEnv() {
  const merged = {
    ...process.env,
    ...loadEnv("development", process.cwd(), ""),
    ...parseEnvFile(".env"),
    ...parseEnvFile(".dev.vars"),
  };

  if (merged.PAGESPEED_API_KEY === undefined || merged.PAGESPEED_API_KEY === "") {
    const envFilePath = fs.existsSync(".env") ? ".env" : null;
    if (envFilePath) {
      const parsed = parseEnvFile(envFilePath);
      if (parsed.PAGESPEED_API_KEY) merged.PAGESPEED_API_KEY = parsed.PAGESPEED_API_KEY;
    }
  }

  return merged;
}

function sendUnauthorized(res, error) {
  sendJson(res, error?.status || 401, {
    error: error?.message || "Unauthorized",
  });
}

// DELETE carries a JSON body in this API (for example the project id sent to
// /api/projects), so it must be forwarded like the other write methods -
// dropping it leaves the handler with an empty body.
const METHODS_WITH_BODY = ["POST", "PUT", "PATCH", "DELETE"];

async function readRawBody(req) {
  if (!req || !METHODS_WITH_BODY.includes(req.method)) return undefined;

  return new Promise((resolve) => {
    const chunks = [];
    req.on("data", (chunk) => chunks.push(Buffer.from(chunk)));
    // Request bodies can be multipart uploads. Returning UTF-8 text here
    // corrupts arbitrary ZIP bytes before Request.formData() sees them.
    const finish = () => {
      const body = Buffer.concat(chunks);
      resolve(body.length ? body : undefined);
    };
    req.on("end", finish);
    req.on("error", finish);
  });
}

/* ── Proxy API middleware (for content tools to fetch external URLs) ── */
function proxyApiPlugin() {
  return {
    name: "seox-proxy-api",
    configureServer(server) {
      server.middlewares.use("/api/proxy", async (req, res) => {
        try {
          try {
            await verifyDevApiRequest(req);
          } catch (error) {
            if (process.env.NODE_ENV !== "development") {
              return sendUnauthorized(res, error);
            }
          }

          const requestUrl = new URL(req.url || "", "http://127.0.0.1");
          const rawBody = await readRawBody(req);
          const headers = new Headers();
          Object.entries(req.headers || {}).forEach(([key, value]) => {
            if (Array.isArray(value)) headers.set(key, value.join(", "));
            else if (value !== undefined) headers.set(key, String(value));
          });

          const request = new Request(`http://127.0.0.1${requestUrl.pathname}${requestUrl.search}`, {
            method: req.method,
            headers,
            body: rawBody ? rawBody : undefined,
          });

          const response = await runNodeHandler({ request, env: loadDevApiEnv() }, proxyHandler);
          res.statusCode = response.status;
          response.headers.forEach((value, key) => {
            res.setHeader(key, value);
          });
          res.end(await response.text());
        } catch (error) {
          sendJson(res, error?.status || 500, {
            error: "Failed to process proxy request",
            message: error?.message || "Unknown error",
          });
        }
      });
    },
  };
}

/* ── DeepSeek API middleware (for AI-powered content tools) ── */
function registerDeepseekMiddleware(server) {
  const handleDeepSeekRequest = async (req, res) => {
        // CORS headers
        res.setHeader("Access-Control-Allow-Origin", "*");
        res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
        res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");

        if (req.method === "OPTIONS") {
          res.statusCode = 200;
          return res.end();
        }

        if (req.method !== "POST") {
          return sendJson(res, 405, { error: "Method not allowed" });
        }

        try {
          await verifyDevApiRequest(req);
        } catch (error) {
          return sendUnauthorized(res, error);
        }

        // Read env using dotenv-style loading
        const env = loadEnv("development", process.cwd(), "");
        const apiKey = env.DEEPSEEK_API_KEY || process.env.DEEPSEEK_API_KEY;

        if (!apiKey) {
          return sendJson(res, 500, {
            error:
              "DeepSeek API key not configured. Add DEEPSEEK_API_KEY to your .env file.",
          });
        }

        // Parse JSON body
        const body = await new Promise((resolve) => {
          let data = "";
          req.on("data", (chunk) => (data += chunk));
          req.on("end", () => {
            try {
              resolve(JSON.parse(data));
            } catch {
              resolve({});
            }
          });
        });

        const {
          prompt,
          systemInstruction,
          responseMimeType,
          temperature = 0.7,
          maxTokens = 8192,
        } = body;

        if (!prompt) {
          return sendJson(res, 400, { error: "Prompt is required" });
        }

        try {
          const wantsJson = responseMimeType === "application/json";
          const systemMessages = [];
          if (systemInstruction) systemMessages.push(systemInstruction);
          if (wantsJson) systemMessages.push("Return valid JSON only.");

          const messages = [];
          if (systemMessages.length > 0) {
            messages.push({
              role: "system",
              content: systemMessages.join("\n\n"),
            });
          }
          messages.push({ role: "user", content: prompt });

          const controller = new AbortController();
          const timeoutId = setTimeout(() => controller.abort(), 60000);

          const response = await fetch(
            "https://api.deepseek.com/chat/completions",
            {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${apiKey}`,
              },
              body: JSON.stringify({
                model: "deepseek-chat",
                messages,
                temperature,
                max_tokens: maxTokens,
                stream: false,
              }),
              signal: controller.signal,
            }
          );
          clearTimeout(timeoutId);

          if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            return sendJson(res, response.status, {
              error:
                errorData.error?.message ||
                `DeepSeek API error: ${response.status}`,
            });
          }

          const data = await response.json();
          const text = data.choices?.[0]?.message?.content || "";

          sendJson(res, 200, {
            text,
            usage: data.usage,
            model: data.model,
          });
        } catch (error) {
          console.error("DeepSeek API error:", error);
          sendJson(res, 500, {
            error: error?.message || "Failed to call DeepSeek API",
          });
        }
  };

  server.middlewares.use("/api/deepseek", handleDeepSeekRequest);
  server.middlewares.use("/api/connect-deepseek", handleDeepSeekRequest);
}

function deepseekApiPlugin() {
  return {
    name: "seox-deepseek-api",
    configureServer: registerDeepseekMiddleware,
    configurePreviewServer: registerDeepseekMiddleware,
  };
}

function deepseekSettingsApiPlugin() {
  return {
    name: "seox-deepseek-settings-api",
    configureServer(server) {
      server.middlewares.use("/api/deepseek-settings", async (req, res) => {
        try {
          const rawBody = await readRawBody(req);
          const headers = new Headers();
          Object.entries(req.headers || {}).forEach(([key, value]) => {
            if (Array.isArray(value)) headers.set(key, value.join(", "));
            else if (value !== undefined) headers.set(key, String(value));
          });
          const request = new Request(mountedUrl(req, "/api/deepseek-settings"), {
            method: req.method || "GET",
            headers,
            body: rawBody || undefined,
          });
          const response = await deepseekSettingsOnRequest({ request, env: loadDevApiEnv() });
          await sendWebResponse(res, response);
        } catch (error) {
          sendJson(res, error?.status || 500, { error: error?.message || "DeepSeek settings request failed" });
        }
      });
    },
    configurePreviewServer(server) {
      server.middlewares.use("/api/deepseek-settings", async (req, res) => {
        try {
          const rawBody = await readRawBody(req);
          const headers = new Headers();
          Object.entries(req.headers || {}).forEach(([key, value]) => {
            if (Array.isArray(value)) headers.set(key, value.join(", "));
            else if (value !== undefined) headers.set(key, String(value));
          });
          const request = new Request(mountedUrl(req, "/api/deepseek-settings"), {
            method: req.method || "GET",
            headers,
            body: rawBody || undefined,
          });
          const response = await deepseekSettingsOnRequest({ request, env: loadDevApiEnv() });
          await sendWebResponse(res, response);
        } catch (error) {
          sendJson(res, error?.status || 500, { error: error?.message || "DeepSeek settings request failed" });
        }
      });
    },
  };
}

/* ── Crawler API middleware (existing) ── */
function crawlerApiPlugin() {
  return {
    name: "seox-crawler-api",
    configureServer(server) {
      registerCrawlerMiddleware(server);
    },
    configurePreviewServer(server) {
      registerCrawlerMiddleware(server);
    },
  };
}

function fetchUrlMetaApiPlugin() {
  return {
    name: "seox-fetch-url-meta-api",
    configureServer(server) {
      registerFetchUrlMetaMiddleware(server);
    },
    configurePreviewServer(server) {
      registerFetchUrlMetaMiddleware(server);
    },
  };
}

function pagespeedApiPlugin() {
  return {
    name: "seox-pagespeed-api",
    configureServer(server) {
      registerPagespeedMiddleware(server);
    },
    configurePreviewServer(server) {
      registerPagespeedMiddleware(server);
    },
  };
}

function screamingFrogApiPlugin() {
  return {
    name: "seox-screaming-frog-api",
    configureServer(server) {
      registerScreamingFrogMiddleware(server);
    },
    configurePreviewServer(server) {
      registerScreamingFrogMiddleware(server);
    },
  };
}

function webmasterApiPlugin() {
  return {
    name: "seox-webmaster-api",
    configureServer(server) {
      registerWebmasterApiMiddleware(server);
    },
    configurePreviewServer(server) {
      registerWebmasterApiMiddleware(server);
    },
  };
}

function autocompleteApiPlugin() {
  return {
    name: "seox-autocomplete-api",
    configureServer(server) {
      registerAutocompleteMiddleware(server);
    },
    configurePreviewServer(server) {
      registerAutocompleteMiddleware(server);
    },
  };
}

// Pages Functions route functions/api/gbp/<name>.js to /api/gbp/<name>; the dev
// server needs the same mapping registered by hand.
const GBP_ROUTES = {
  "/api/gbp/connect": gbpConnectOnRequest,
  "/api/gbp/accounts": gbpAccountsOnRequest,
  "/api/gbp/locations": gbpLocationsOnRequest,
  "/api/gbp/overview": gbpOverviewOnRequest,
  "/api/gbp/profile": gbpProfileOnRequest,
  "/api/gbp/audit": gbpAuditOnRequest,
  "/api/gbp/posts": gbpPostsOnRequest,
  "/api/gbp/automation": gbpAutomationOnRequest,
  "/api/gbp/jobs": gbpJobsOnRequest,
  "/api/gbp/reviews": gbpReviewsOnRequest,
  "/api/gbp/insights": gbpInsightsOnRequest,
  "/api/gbp/qanda": gbpQandaOnRequest,
  "/api/gbp/recommendations": gbpRecommendationsOnRequest,
  "/api/gbp/history": gbpHistoryOnRequest,
};

function registerGbpMiddleware(server) {
  for (const [mountPath, handler] of Object.entries(GBP_ROUTES)) {
    server.middlewares.use(mountPath, async (req, res) => {
      try {
        const request = await createWebRequest(req, mountPath);
        const response = await handler({ request, env: loadDevApiEnv() });
        await sendWebResponse(res, response);
      } catch (error) {
        sendJson(res, error?.status || 500, {
          error: "Business Profile request failed",
          message: error?.message || "Unknown error",
        });
      }
    });
  }
}

function gbpApiPlugin() {
  return {
    name: "seox-gbp-api",
    configureServer(server) {
      registerGbpMiddleware(server);
    },
    configurePreviewServer(server) {
      registerGbpMiddleware(server);
    },
  };
}

// Pages Functions route functions/api/jira/<name>.js to /api/jira/<name>; as
// with GBP, the Node process that serves the app needs the same mapping
// registered by hand. Production runs `vite preview` on :4173 and serves
// /api/* from these very middlewares, so every route MUST be registered for
// configurePreviewServer as well as configureServer - a route registered only
// for dev works locally and 404s in production.
//
// *** ORDER IS SIGNIFICANT FOR /api/jira/issues/status ***
// Connect's `use(path, fn)` matches on a PREFIX, so the "/api/jira/issues"
// middleware also matches "/api/jira/issues/status". The longer path must
// therefore be registered FIRST, or every status request is swallowed by the
// issues route and answered as an eligible-issues feed. Object key order is
// insertion order for non-numeric keys, and registerJiraMiddleware walks it
// in that order, so this listing IS the precedence.
const JIRA_ROUTES = {
  "/api/jira/issues/status": jiraIssueStatusOnRequest,
  "/api/jira/connect": jiraConnectOnRequest,
  "/api/jira/status": jiraStatusOnRequest,
  "/api/jira/metadata": jiraMetadataOnRequest,
  "/api/jira/mapping": jiraMappingOnRequest,
  "/api/jira/issues": jiraIssuesOnRequest,
  "/api/jira/webhook": jiraWebhookOnRequest,
  "/api/jira/jobs": jiraJobsOnRequest,
};

function registerJiraMiddleware(server) {
  for (const [mountPath, handler] of Object.entries(JIRA_ROUTES)) {
    server.middlewares.use(mountPath, async (req, res) => {
      try {
        const request = await createWebRequest(req, mountPath);
        const response = await handler({ request, env: loadDevApiEnv() });
        await sendWebResponse(res, response);
      } catch (error) {
        sendJson(res, error?.status || 500, {
          error: "Jira request failed",
          message: error?.message || "Unknown error",
        });
      }
    });
  }
}

function jiraApiPlugin() {
  return {
    name: "seox-jira-api",
    configureServer(server) {
      registerJiraMiddleware(server);
    },
    configurePreviewServer(server) {
      registerJiraMiddleware(server);
    },
  };
}

function gscTokenApiPlugin() {
  return {
    name: "seox-gsc-token-api",
    configureServer(server) {
      registerGscTokenMiddleware(server);
    },
    configurePreviewServer(server) {
      registerGscTokenMiddleware(server);
    },
  };
}

function projectsApiPlugin() {
  return {
    name: "seox-projects-api",
    configureServer(server) {
      registerProjectsMiddleware(server);
    },
    configurePreviewServer(server) {
      registerProjectsMiddleware(server);
    },
  };
}

function projectDetailsApiPlugin() {
  return {
    name: "seox-project-details-api",
    configureServer(server) {
      registerProjectDetailsMiddleware(server);
    },
    configurePreviewServer(server) {
      registerProjectDetailsMiddleware(server);
    },
  };
}

function backlinksAnalyzeApiPlugin() {
  return {
    name: "seox-backlinks-analyze-api",
    configureServer(server) {
      registerBacklinksAnalyzeMiddleware(server);
    },
    configurePreviewServer(server) {
      registerBacklinksAnalyzeMiddleware(server);
    },
  };
}

// General Settings API. `admin_settings` is the single source of truth for the
// application-wide credentials, so these routes must run in the Node process
// that serves /api/* - registered for `vite dev` AND `vite preview` (:4173).
const SETTINGS_ROUTES = {
  "/api/settings/general": generalSettingsOnRequest,
  "/api/settings/public": publicSettingsOnRequest,
};

function registerSettingsMiddleware(server) {
  for (const [mountPath, handler] of Object.entries(SETTINGS_ROUTES)) {
    server.middlewares.use(mountPath, async (req, res) => {
      try {
        const request = await createWebRequest(req, mountPath);
        const response = await handler({ request, env: loadDevApiEnv() });
        await sendWebResponse(res, response);
      } catch (error) {
        sendJson(res, error?.status || 500, {
          error: "Settings request failed",
          message: error?.message || "Unknown error",
        });
      }
    });
  }
}

function settingsApiPlugin() {
  return {
    name: "seox-settings-api",
    configureServer(server) {
      registerSettingsMiddleware(server);
    },
    configurePreviewServer(server) {
      registerSettingsMiddleware(server);
    },
  };
}

function w3cValidationApiPlugin() {
  return {
    name: "seox-w3c-validation-api",
    configureServer(server) {
      registerW3CValidationMiddleware(server);
      registerAdminW3CValidationMiddleware(server);
    },
    configurePreviewServer(server) {
      registerW3CValidationMiddleware(server);
      registerAdminW3CValidationMiddleware(server);
    },
  };
}

function expiredDomainsCheckApiPlugin() {
  return {
    name: "seox-expired-domains-check-api",
    configureServer(server) {
      registerExpiredDomainsCheckMiddleware(server);
    },
    configurePreviewServer(server) {
      registerExpiredDomainsCheckMiddleware(server);
    },
  };
}

function backlinkCleanerApiPlugin() {
  return {
    name: "seox-backlink-cleaner-api",
    configureServer(server) {
      registerBacklinkCleanerMiddleware(server);
    },
    configurePreviewServer(server) {
      registerBacklinkCleanerMiddleware(server);
    },
  };
}

function backlinkIndexerApiPlugin() {
  return {
    name: "seox-backlink-indexer-api",
    configureServer(server) {
      registerBacklinkIndexerMiddleware(server);
    },
    configurePreviewServer(server) {
      registerBacklinkIndexerMiddleware(server);
    },
  };
}

function keywordResearchApiPlugin() {
  return {
    name: "seox-keyword-research-api",
    configureServer(server) {
      registerKeywordResearchMiddleware(server);
    },
    configurePreviewServer(server) {
      registerKeywordResearchMiddleware(server);
    },
  };
}

function ubersuggestApiPlugin() {
  return {
    name: "seox-ubersuggest-api",
    configureServer(server) {
      registerUbersuggestMiddleware(server);
    },
    configurePreviewServer(server) {
      registerUbersuggestMiddleware(server);
    },
  };
}

function authApiPlugin() {
  return {
    name: "seox-auth-api",
    configureServer(server) {
      registerAuthMiddleware(server);
    },
    configurePreviewServer(server) {
      registerAuthMiddleware(server);
    },
  };
}

function contentOutlineApiPlugin() {
  return {
    name: "seox-content-outline-api",
    configureServer(server) {
      registerContentOutlineMiddleware(server);
    },
    configurePreviewServer(server) {
      registerContentOutlineMiddleware(server);
    },
  };
}

function contentNlpApiPlugin() {
  return {
    name: "seox-content-nlp-api",
    configureServer(server) {
      registerContentNlpMiddleware(server);
    },
    configurePreviewServer(server) {
      registerContentNlpMiddleware(server);
    },
  };
}

function contentGrammarApiPlugin() {
  return {
    name: "seox-content-grammar-api",
    configureServer(server) {
      registerContentGrammarMiddleware(server);
    },
    configurePreviewServer(server) {
      registerContentGrammarMiddleware(server);
    },
  };
}

function contentUniqueNgramsApiPlugin() {
  return {
    name: "seox-content-unique-ngrams-api",
    configureServer(server) {
      registerContentUniqueNgramsMiddleware(server);
    },
    configurePreviewServer(server) {
      registerContentUniqueNgramsMiddleware(server);
    },
  };
}

function contentSkipGramApiPlugin() {
  return {
    name: "seox-content-skip-gram-api",
    configureServer(server) {
      registerContentSkipGramMiddleware(server);
    },
    configurePreviewServer(server) {
      registerContentSkipGramMiddleware(server);
    },
  };
}

function contentOptimizationApiPlugin() {
  return {
    name: "seox-content-optimization-api",
    configureServer(server) {
      registerContentOptimizationMiddleware(server);
    },
    configurePreviewServer(server) {
      registerContentOptimizationMiddleware(server);
    },
  };
}

function contentWatermarkRemoverApiPlugin() {
  return {
    name: "seox-content-watermark-remover-api",
    configureServer(server) {
      registerContentWatermarkRemoverMiddleware(server);
    },
    configurePreviewServer(server) {
      registerContentWatermarkRemoverMiddleware(server);
    },
  };
}

function contentSemanticGeneratorApiPlugin() {
  return {
    name: "seox-content-semantic-generator-api",
    configureServer(server) {
      registerContentSemanticGeneratorMiddleware(server);
    },
    configurePreviewServer(server) {
      registerContentSemanticGeneratorMiddleware(server);
    },
  };
}

function contentAnalyzerApiPlugin() {
  return {
    name: "seox-content-content-analyzer-api",
    configureServer(server) {
      registerContentAnalyzerMiddleware(server);
    },
    configurePreviewServer(server) {
      registerContentAnalyzerMiddleware(server);
    },
  };
}

function contentNgramsApiPlugin() {
  return {
    name: "seox-content-ngrams-api",
    configureServer(server) {
      registerContentNgramsMiddleware(server);
    },
    configurePreviewServer(server) {
      registerContentNgramsMiddleware(server);
    },
  };
}

function entitiesGeneratorApiPlugin() {
  return {
    name: "seox-entities-generator-api",
    configureServer(server) {
      registerEntitiesGeneratorMiddleware(server);
    },
    configurePreviewServer(server) {
      registerEntitiesGeneratorMiddleware(server);
    },
  };
}

function entitiesExtractorApiPlugin() {
  return {
    name: "seox-entities-extractor-api",
    configureServer(server) {
      registerEntitiesExtractorMiddleware(server);
    },
    configurePreviewServer(server) {
      registerEntitiesExtractorMiddleware(server);
    },
  };
}

function aiHelperApiPlugin() {
  return {
    name: "seox-ai-helper-api",
    configureServer(server) {
      registerAiHelperMiddleware(server);
    },
    configurePreviewServer(server) {
      registerAiHelperMiddleware(server);
    },
  };
}

function textEditorApiPlugin() {
  return {
    name: "seox-text-editor-api",
    configureServer(server) {
      registerTextEditorMiddleware(server);
    },
    configurePreviewServer(server) {
      registerTextEditorMiddleware(server);
    },
  };
}

function domainSeparatorApiPlugin() {
  return {
    name: "seox-domain-separator-api",
    configureServer(server) {
      registerDomainSeparatorMiddleware(server);
    },
    configurePreviewServer(server) {
      registerDomainSeparatorMiddleware(server);
    },
  };
}

function wordCounterApiPlugin() {
  return {
    name: "seox-word-counter-api",
    configureServer(server) {
      registerWordCounterMiddleware(server);
    },
    configurePreviewServer(server) {
      registerWordCounterMiddleware(server);
    },
  };
}

function botViewerApiPlugin() {
  return {
    name: "seox-bot-viewer-api",
    configureServer(server) {
      registerBotViewerMiddleware(server);
    },
    configurePreviewServer(server) {
      registerBotViewerMiddleware(server);
    },
  };
}

function daPaCheckerApiPlugin() {
  return {
    name: "seox-da-pa-checker-api",
    configureServer(server) {
      registerDaPaCheckerMiddleware(server);
    },
    configurePreviewServer(server) {
      registerDaPaCheckerMiddleware(server);
    },
  };
}

function metaExtractorApiPlugin() {
  return {
    name: "seox-meta-extractor-api",
    configureServer(server) {
      registerMetaExtractorMiddleware(server);
    },
    configurePreviewServer(server) {
      registerMetaExtractorMiddleware(server);
    },
  };
}

function sitemapExtractorApiPlugin() {
  return {
    name: "seox-sitemap-extractor-api",
    configureServer(server) {
      registerSitemapExtractorMiddleware(server);
    },
    configurePreviewServer(server) {
      registerSitemapExtractorMiddleware(server);
    },
  };
}

function seoToolsApiPlugin() {
  return {
    name: "seox-seo-tools-api",
    configureServer(server) {
      registerSeoToolsMiddleware(server);
    },
    configurePreviewServer(server) {
      registerSeoToolsMiddleware(server);
    },
  };
}

function promptTrackingApiPlugin() {
  return {
    name: "seox-prompt-tracking-api",
    configureServer(server) {
      registerPromptTrackingMiddleware(server);
    },
    configurePreviewServer(server) {
      registerPromptTrackingMiddleware(server);
    },
  };
}

function brandSentimentApiPlugin() {
  return {
    name: "seox-brand-sentiment-api",
    configureServer(server) {
      registerBrandSentimentMiddleware(server);
    },
    configurePreviewServer(server) {
      registerBrandSentimentMiddleware(server);
    },
  };
}

function citationFlowApiPlugin() {
  return {
    name: "seox-citation-flow-api",
    configureServer(server) {
      registerCitationFlowMiddleware(server);
    },
    configurePreviewServer(server) {
      registerCitationFlowMiddleware(server);
    },
  };
}

function competitorResearchApiPlugin() {
  return {
    name: "seox-competitor-research-api",
    configureServer(server) {
      registerCompetitorResearchMiddleware(server);
    },
    configurePreviewServer(server) {
      registerCompetitorResearchMiddleware(server);
    },
  };
}

function internalLinksApiPlugin() {
  return {
    name: "seox-internal-links-api",
    configureServer(server) {
      registerInternalLinksMiddleware(server);
    },
    configurePreviewServer(server) {
      registerInternalLinksMiddleware(server);
    },
  };
}

function aiChatApiPlugin() {
  return {
    name: "seox-ai-chat-api",
    configureServer(server) {
      registerAiChatMiddleware(server);
    },
    configurePreviewServer(server) {
      registerAiChatMiddleware(server);
    },
  };
}

function llmsGeneratorApiPlugin() {
  return {
    name: "seox-llms-generator-api",
    configureServer(server) {
      registerLlmsGeneratorMiddleware(server);
    },
    configurePreviewServer(server) {
      registerLlmsGeneratorMiddleware(server);
    },
  };
}

function aiModelCheckerApiPlugin() {
  return {
    name: "seox-ai-model-checker-api",
    configureServer(server) {
      registerAiModelCheckerMiddleware(server);
    },
    configurePreviewServer(server) {
      registerAiModelCheckerMiddleware(server);
    },
  };
}

function aiCompatibilityApiPlugin() {
  return {
    name: "seox-ai-compatibility-api",
    configureServer(server) {
      registerAiCompatibilityMiddleware(server);
    },
    configurePreviewServer(server) {
      registerAiCompatibilityMiddleware(server);
    },
  };
}

function semanticWriterEditorApiPlugin() {
  return {
    name: "seox-semantic-writer-editor-api",
    configureServer(server) {
      registerSemanticWriterEditorMiddleware(server);
    },
    configurePreviewServer(server) {
      registerSemanticWriterEditorMiddleware(server);
    },
  };
}

function contentWriterApiPlugin() {
  return {
    name: "seox-content-writer-api",
    configureServer(server) {
      registerContentWriterMiddleware(server);
    },
    configurePreviewServer(server) {
      registerContentWriterMiddleware(server);
    },
  };
}

function auditorApiPlugin() {
  return {
    name: "seox-auditor-api",
    configureServer(server) {
      registerAuditorMiddleware(server);
    },
    configurePreviewServer(server) {
      registerAuditorMiddleware(server);
    },
  };
}

function mountedUrl(req, mountPath) {
  const forwardedHost = String(req.headers?.["x-forwarded-host"] || req.headers?.host || "").split(",")[0].trim();
  const host = /^[a-z0-9.:[\]-]+$/i.test(forwardedHost) ? forwardedHost : "127.0.0.1:3000";
  const forwardedProtocol = String(req.headers?.["x-forwarded-proto"] || "").split(",")[0].trim().toLowerCase();
  const protocol = forwardedProtocol === "https" ? "https" : "http";
  const origin = `${protocol}://${host}`;
  const raw = req.url || "";
  if (raw.startsWith(mountPath)) return `${origin}${raw}`;
  if (raw.startsWith("/?")) return `${origin}${mountPath}${raw.slice(1)}`;
  if (raw.startsWith("?")) return `${origin}${mountPath}${raw}`;
  if (!raw || raw === "/") return `${origin}${mountPath}`;
  return `${origin}${mountPath}${raw.startsWith("/") ? raw : `/${raw}`}`;
}

function registerFetchUrlMetaMiddleware(server) {
  server.middlewares.use("/api/fetch-url-meta", async (req, res) => {
    const requestUrl = new URL(req.url || "", "http://127.0.0.1");
    const query = Object.fromEntries(requestUrl.searchParams.entries());
    const body = ["POST", "PUT", "PATCH"].includes(req.method || "")
      ? await readJsonBody(req)
      : {};

    await fetchUrlMetaHandler(
      { method: req.method || "GET", headers: req.headers, query, body },
      createNodeJsonResponse(res)
    );
  });
}

function registerAutocompleteMiddleware(server) {
  server.middlewares.use("/api/autocomplete", async (req, res) => {
    try {
      const response = await autocompleteOnRequest({
        request: new Request(mountedUrl(req, "/api/autocomplete"), {
          method: req.method || "GET",
          headers: req.headers,
        }),
      });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, 500, {
        error: "Autocomplete request failed",
        message: error?.message || "Unknown error",
      });
    }
  });
}

function registerPagespeedMiddleware(server) {
  server.middlewares.use("/api/pagespeed", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/pagespeed");
      const response = await pagespeedOnRequest({
        request,
        env: loadDevApiEnv(),
      });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, {
        error: "PageSpeed request failed",
        message: error?.message || "Unknown error",
      });
    }
  });
}

function registerSpeedMiddleware(server) {
  const handleSpeedRequest = async (req, res, path) => {
        try {
          const request = await createWebRequest(req, path);
          const response = await speedOnRequest({ request, env: loadDevApiEnv() });
          await sendWebResponse(res, response);
        } catch (error) {
          sendJson(res, error?.status || 500, { success: false, error: error?.message || "Speed test request failed" });
        }
  };

  server.middlewares.use("/api/tech-seo/speed", (req, res) =>
    handleSpeedRequest(req, res, "/api/tech-seo/speed")
  );
  server.middlewares.use("/api/tech-seo/speed-test", (req, res) =>
    handleSpeedRequest(req, res, "/api/tech-seo/speed-test")
  );
}

function speedApiPlugin() {
  return {
    name: "seox-speed-api",
    configureServer: registerSpeedMiddleware,
    configurePreviewServer: registerSpeedMiddleware,
  };
}

function registerWordpressSecurityMiddleware(server) {
  server.middlewares.use("/api/tech-seo/wordpress-security", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/tech-seo/wordpress-security");
      const response = await wordpressSecurityOnRequest({ request, env: loadDevApiEnv() });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, {
        error: "WordPress security scan failed",
        message: error?.message || "Unknown error",
      });
    }
  });
}

function wordpressSecurityApiPlugin() {
  return {
    name: "seox-wordpress-security-api",
    configureServer: registerWordpressSecurityMiddleware,
    configurePreviewServer: registerWordpressSecurityMiddleware,
  };
}

function registerScreamingFrogMiddleware(server) {
  server.middlewares.use("/api/tech-seo/screaming-frog/url-reports", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/tech-seo/screaming-frog/url-reports");
      const response = await screamingFrogUrlReportsOnRequest({ request, env: loadDevApiEnv() });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, { success: false, error: error?.message || "Screaming Frog URL report storage failed." });
    }
  });
  server.middlewares.use("/api/tech-seo/screaming-frog/report-download", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/tech-seo/screaming-frog/report-download");
      const response = await screamingFrogReportDownloadOnRequest({ request, env: loadDevApiEnv() });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, { status: "error", success: false, message: error?.message || "Screaming Frog report download failed." });
    }
  });
  server.middlewares.use("/api/tech-seo/screaming-frog", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/tech-seo/screaming-frog");
      const response = await screamingFrogOnRequest({ request, env: loadDevApiEnv() });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, {
        status: "error",
        success: false,
        message: error?.message || "Screaming Frog request failed.",
        errors: [],
      });
    }
  });
}

function registerGscTokenMiddleware(server) {
  server.middlewares.use("/api/gsc-token", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/gsc-token");
      const response = await gscTokenOnRequest({
        request,
        env: loadDevApiEnv(),
      });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, {
        error: "GSC token request failed",
        message: error?.message || "Unknown error",
      });
    }
  });
}

function registerProjectsMiddleware(server) {
  server.middlewares.use("/api/projects", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/projects");
      const response = await projectsOnRequest({
        request,
        env: loadDevApiEnv(),
      });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, {
        error: "Projects request failed",
        message: error?.message || "Unknown error",
      });
    }
  });
}

function registerProjectDetailsMiddleware(server) {
  const handleProjectDetailsRequest = async (req, res, mountPath) => {
    try {
      const request = await createWebRequest(req, mountPath);
      const response = await projectDetailsOnRequest({
        request,
        env: loadDevApiEnv(),
      });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, 500, {
        error: "Project details request failed",
        message: error?.message || "Unknown error",
      });
    }
  };

  server.middlewares.use("/api/project-details", async (req, res) => {
    await handleProjectDetailsRequest(req, res, "/api/project-details");
  });

  server.middlewares.use("/api/add-project-detail", async (req, res) => {
    await handleProjectDetailsRequest(req, res, "/api/add-project-detail");
  });
}

function registerBacklinksAnalyzeMiddleware(server) {
  server.middlewares.use("/api/tech-seo/backlinks/analyze", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/tech-seo/backlinks/analyze");
      const response = await backlinksAnalyzeOnRequest({ request, env: loadDevApiEnv() });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, {
        success: false,
        error: error?.message || "Backlink analysis request failed.",
      });
    }
  });
}

function registerW3CValidationMiddleware(server) {
  server.middlewares.use("/api/tech-seo/w3c/validate", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/tech-seo/w3c/validate");
      const response = await w3cValidateOnRequest({ request, env: loadDevApiEnv() });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, {
        success: false,
        error: error?.message || "W3C validation request failed.",
      });
    }
  });
}

function registerAdminW3CValidationMiddleware(server) {
  server.middlewares.use("/api/tech-seo/w3c-validation", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/tech-seo/w3c-validation");
      const response = await adminW3cValidateOnRequest({ request, env: loadDevApiEnv() });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, {
        success: false,
        error: error?.message || "W3C validation request failed.",
      });
    }
  });
}

function registerExpiredDomainsCheckMiddleware(server) {
  server.middlewares.use("/api/off-page/expired-domains/check", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/off-page/expired-domains/check");
      const response = await expiredDomainsCheckOnRequest({ request, env: loadDevApiEnv() });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, {
        success: false,
        error: error?.message || "Expired domain check request failed.",
      });
    }
  });
}

function registerBacklinkCleanerMiddleware(server) {
  server.middlewares.use("/api/off-page/backlink-cleaner", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/off-page/backlink-cleaner");
      const response = await backlinkCleanerOnRequest({ request, env: loadDevApiEnv() });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, {
        success: false,
        error: error?.message || "Backlink cleaner request failed.",
      });
    }
  });
}

function registerBacklinkIndexerMiddleware(server) {
  server.middlewares.use("/api/off-page/backlink-indexer", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/off-page/backlink-indexer");
      const response = await backlinkIndexerOnRequest({ request, env: loadDevApiEnv() });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, {
        success: false,
        error: error?.message || "Backlink indexer request failed.",
      });
    }
  });
}

function registerKeywordResearchMiddleware(server) {
  server.middlewares.use("/api/keywords/research", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/keywords/research");
      const response = await keywordResearchOnRequest({ request, env: loadDevApiEnv() });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, {
        success: false,
        error: error?.message || "Keyword research request failed.",
      });
    }
  });
}

function registerUbersuggestMiddleware(server) {
  server.middlewares.use("/api/keywords/ubersuggest", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/keywords/ubersuggest");
      const response = await ubersuggestOnRequest({ request, env: loadDevApiEnv() });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, {
        success: false,
        error: error?.message || "Ubersuggest request failed.",
      });
    }
  });
}

function registerAuthMiddleware(server) {
  server.middlewares.use("/api/auth", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/auth");
      const handler = request.method === "GET" ? authOnRequestGet : authOnRequestPost;
      const response = await handler({ request, env: loadDevApiEnv() });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, {
        ok: false,
        error: error?.message || "Authentication request failed",
      });
    }
  });
}

function registerContentOutlineMiddleware(server) {
  server.middlewares.use("/api/content/outline", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/content/outline");
      const response = await contentOutlineOnRequest({ request, env: loadDevApiEnv() });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, {
        success: false,
        message: error?.message || "Outline generation request failed.",
      });
    }
  });
}

function registerContentNlpMiddleware(server) {
  server.middlewares.use("/api/content/nlp", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/content/nlp");
      const response = await contentNlpOnRequest({ request, env: loadDevApiEnv() });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, {
        success: false,
        status: "error",
        message: error?.message || "NLP request failed.",
      });
    }
  });
}

function registerContentGrammarMiddleware(server) {
  server.middlewares.use("/api/content/grammar", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/content/grammar");
      const response = await contentGrammarOnRequest({ request, env: loadDevApiEnv() });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, {
        success: false,
        status: "error",
        message: error?.message || "Grammar request failed.",
      });
    }
  });
}

function registerContentUniqueNgramsMiddleware(server) {
  server.middlewares.use("/api/content/unique-ngrams", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/content/unique-ngrams");
      const response = await contentUniqueNgramsOnRequest({ request, env: loadDevApiEnv() });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, {
        success: false,
        status: "error",
        message: error?.message || "Unique n-grams request failed.",
      });
    }
  });
}

function registerContentSkipGramMiddleware(server) {
  server.middlewares.use("/api/content/skip-gram", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/content/skip-gram");
      const response = await contentSkipGramOnRequest({ request, env: loadDevApiEnv() });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, {
        success: false,
        status: "error",
        message: error?.message || "Skip-gram request failed.",
      });
    }
  });
}

function registerContentOptimizationMiddleware(server) {
  server.middlewares.use("/api/content/optimization", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/content/optimization");
      const response = await contentOptimizationOnRequest({ request, env: loadDevApiEnv() });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, {
        success: false,
        status: "error",
        message: error?.message || "Content optimization request failed.",
      });
    }
  });
}

function registerContentWatermarkRemoverMiddleware(server) {
  server.middlewares.use("/api/content/watermark-remover", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/content/watermark-remover");
      const response = await contentWatermarkRemoverOnRequest({ request, env: loadDevApiEnv() });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, {
        success: false,
        status: "error",
        message: error?.message || "Watermark remover request failed.",
      });
    }
  });
}

function registerContentSemanticGeneratorMiddleware(server) {
  server.middlewares.use("/api/content/semantic-generator", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/content/semantic-generator");
      const response = await contentSemanticGeneratorOnRequest({ request, env: loadDevApiEnv() });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, {
        success: false,
        status: "error",
        message: error?.message || "Semantic generator request failed.",
      });
    }
  });
}

function registerContentAnalyzerMiddleware(server) {
  server.middlewares.use("/api/content/content-analyzer", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/content/content-analyzer");
      const response = await contentAnalyzerOnRequest({ request, env: loadDevApiEnv() });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, {
        success: false,
        status: "error",
        message: error?.message || "Content analyzer request failed.",
      });
    }
  });
}

function registerContentNgramsMiddleware(server) {
  server.middlewares.use("/api/content/ngrams", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/content/ngrams");
      const response = await contentNgramsOnRequest({ request, env: loadDevApiEnv() });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, {
        success: false,
        status: "error",
        message: error?.message || "N-grams request failed.",
      });
    }
  });
}

function registerEntitiesGeneratorMiddleware(server) {
  server.middlewares.use("/api/content/entities-generator", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/content/entities-generator");
      const response = await entitiesGeneratorOnRequest({ request, env: loadDevApiEnv() });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, {
        success: false,
        status: "error",
        message: error?.message || "Entities generator request failed.",
      });
    }
  });
}

function registerEntitiesExtractorMiddleware(server) {
  server.middlewares.use("/api/content/entities-extractor", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/content/entities-extractor");
      const response = await entitiesExtractorOnRequest({ request, env: loadDevApiEnv() });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, {
        success: false,
        status: "error",
        message: error?.message || "Entities extractor request failed.",
      });
    }
  });
}

function registerAiHelperMiddleware(server) {
  server.middlewares.use("/api/content/ai-helper", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/content/ai-helper");
      const response = await aiHelperOnRequest({ request, env: loadDevApiEnv() });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, {
        success: false,
        status: "error",
        message: error?.message || "AI Helper request failed.",
      });
    }
  });
}

function registerTextEditorMiddleware(server) {
  server.middlewares.use("/api/seo-tools/text-editor", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/seo-tools/text-editor");
      const response = await textEditorOnRequest({ request, env: loadDevApiEnv() });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, {
        success: false,
        status: "error",
        message: error?.message || "Text editor request failed.",
      });
    }
  });
}

function registerDomainSeparatorMiddleware(server) {
  server.middlewares.use("/api/seo-tools/domain-separator", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/seo-tools/domain-separator");
      const response = await domainSeparatorOnRequest({ request, env: loadDevApiEnv() });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, {
        success: false,
        status: "error",
        message: error?.message || "Domain separator request failed.",
        data: null,
      });
    }
  });
}

function registerWordCounterMiddleware(server) {
  server.middlewares.use("/api/seo-tools/word-counter", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/seo-tools/word-counter");
      const response = await wordCounterOnRequest({ request, env: loadDevApiEnv() });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, {
        success: false,
        status: "error",
        message: error?.message || "Word counter request failed.",
        data: null,
      });
    }
  });
}

function registerBotViewerMiddleware(server) {
  server.middlewares.use("/api/seo-tools/bot-viewer", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/seo-tools/bot-viewer");
      const response = await botViewerOnRequest({ request, env: loadDevApiEnv() });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, {
        success: false,
        status: "error",
        message: error?.message || "Bot viewer request failed.",
        data: null,
      });
    }
  });
}

function registerDaPaCheckerMiddleware(server) {
  server.middlewares.use("/api/seo-tools/da-pa-checker", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/seo-tools/da-pa-checker");
      const response = await daPaCheckerOnRequest({ request, env: loadDevApiEnv() });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, {
        success: false,
        status: "error",
        message: error?.message || "DA/PA checker request failed.",
        data: null,
      });
    }
  });
}

function registerMetaExtractorMiddleware(server) {
  server.middlewares.use("/api/seo-tools/meta-extractor", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/seo-tools/meta-extractor");
      const response = await metaExtractorOnRequest({ request, env: loadDevApiEnv() });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, {
        success: false,
        status: "error",
        message: error?.message || "Meta extractor request failed.",
        data: null,
      });
    }
  });
}

function registerSitemapExtractorMiddleware(server) {
  server.middlewares.use("/api/seo-tools/sitemap-extractor", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/seo-tools/sitemap-extractor");
      const response = await sitemapExtractorOnRequest({ request, env: loadDevApiEnv() });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, {
        success: false,
        status: "error",
        message: error?.message || "Sitemap extractor request failed.",
        data: null,
      });
    }
  });
}

function registerSeoToolsMiddleware(server) {
  server.middlewares.use("/api/seo-tools", async (req, res, next) => {
    if (req.url && req.url !== "/" && !req.url.startsWith("/?")) return next();
    try {
      const request = await createWebRequest(req, "/api/seo-tools");
      const response = await seoToolsOnRequest({ request, env: loadDevApiEnv() });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, {
        success: false,
        status: "error",
        message: error?.message || "SEO tools request failed.",
        tool: null,
        data: null,
      });
    }
  });
}

function registerPromptTrackingMiddleware(server) {
  server.middlewares.use("/api/geo/prompt-tracking", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/geo/prompt-tracking");
      const response = await promptTrackingOnRequest({ request, env: loadDevApiEnv() });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, {
        success: false,
        status: "error",
        message: error?.message || "Prompt tracking request failed.",
        data: null,
      });
    }
  });
}

function registerBrandSentimentMiddleware(server) {
  server.middlewares.use("/api/geo/brand-sentiment", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/geo/brand-sentiment");
      const response = await brandSentimentOnRequest({ request, env: loadDevApiEnv() });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, {
        success: false,
        status: "error",
        message: error?.message || "Brand sentiment request failed.",
        data: null,
      });
    }
  });
}

function registerCitationFlowMiddleware(server) {
  server.middlewares.use("/api/geo/citation-flow", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/geo/citation-flow");
      const response = await citationFlowOnRequest({ request, env: loadDevApiEnv() });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, { success: false, status: "error", message: error?.message || "Citation Flow request failed.", data: null });
    }
  });
}

function registerCompetitorResearchMiddleware(server) {
  server.middlewares.use("/api/geo/competitor-research", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/geo/competitor-research");
      const response = await competitorResearchOnRequest({ request, env: loadDevApiEnv() });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, { success: false, status: "error", message: error?.message || "Competitor research request failed.", data: null });
    }
  });
}

function registerInternalLinksMiddleware(server) {
  server.middlewares.use("/api/geo/internal-links", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/geo/internal-links");
      const response = await internalLinksOnRequest({ request, env: loadDevApiEnv() });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, { success: false, status: "error", message: error?.message || "Internal links request failed.", data: null });
    }
  });
}

function registerAiChatMiddleware(server) {
  server.middlewares.use("/api/geo/ai-chat", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/geo/ai-chat");
      const response = await aiChatOnRequest({ request, env: loadDevApiEnv() });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, { success: false, status: "error", message: error?.message || "AI chat request failed.", data: null });
    }
  });
}

function registerLlmsGeneratorMiddleware(server) {
  server.middlewares.use("/api/geo/llms-generator", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/geo/llms-generator");
      const response = await llmsGeneratorOnRequest({ request, env: loadDevApiEnv() });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, { success: false, status: "error", message: error?.message || "LLMs Generator request failed.", data: null });
    }
  });
}

function registerAiModelCheckerMiddleware(server) {
  server.middlewares.use("/api/geo/ai-model-checker", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/geo/ai-model-checker");
      const response = await aiModelCheckerOnRequest({ request, env: loadDevApiEnv() });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, { success: false, status: "error", message: error?.message || "AI Model Checker request failed.", data: null });
    }
  });
}

function registerAiCompatibilityMiddleware(server) {
  server.middlewares.use("/api/geo/ai-compatibility", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/geo/ai-compatibility");
      const response = await aiCompatibilityOnRequest({ request, env: loadDevApiEnv() });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, { success: false, status: "error", message: error?.message || "AI Compatibility request failed.", data: null });
    }
  });
}

function registerSemanticWriterEditorMiddleware(server) {
  server.middlewares.use("/api/content/semantic-writer/editor", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/content/semantic-writer/editor");
      const response = await semanticWriterEditorOnRequest({ request, env: loadDevApiEnv() });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, { success: false, status: "error", message: error?.message || "Semantic Writer Editor request failed.", data: null });
    }
  });
}

function registerContentWriterMiddleware(server) {
  server.middlewares.use("/api/content-writer", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/content-writer");
      const response = await contentWriterOnRequest({ request, env: loadDevApiEnv() });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, { error: error?.message || "Content profile request failed." });
    }
  });
}

function registerAuditorMiddleware(server) {
  server.middlewares.use("/api/auditor", async (req, res) => {
    try {
      const request = await createWebRequest(req, "/api/auditor");
      const response = await auditorOnRequest({ request, env: loadDevApiEnv() });
      await sendWebResponse(res, response);
    } catch (error) {
      sendJson(res, error?.status || 500, { success: false, status: "error", message: error?.message || "Auditor request failed.", data: null });
    }
  });
}

function registerWebmasterApiMiddleware(server) {
  server.middlewares.use("/api/webmaster-api", async (req, res) => {
    let decoded;
    try {
      decoded = await verifyDevApiRequest(req);
    } catch (error) {
      return sendUnauthorized(res, error);
    }

    const requestUrl = new URL(req.url || "", "http://127.0.0.1");
    const query = Object.fromEntries(requestUrl.searchParams.entries());
    const body = ["POST", "PUT", "PATCH"].includes(req.method || "")
      ? await readJsonBody(req)
      : {};

    await webmasterApiHandler(
      {
        method: req.method || "GET",
        query,
        body,
        env: loadDevApiEnv(),
        user: decoded,
      },
      createNodeJsonResponse(res)
    );
  });
}

function registerCrawlerMiddleware(server) {
  server.middlewares.use("/api/crawler/fetch", async (req, res) => {
    try {
      try {
        await verifyDevApiRequest(req);
      } catch (error) {
        sendUnauthorized(res, error);
        return;
      }

      const requestUrl = new URL(req.url || "", "http://127.0.0.1");
      const targetRaw = requestUrl.searchParams.get("url");
      if (!targetRaw) {
        sendJson(res, 400, { error: "Missing url parameter" });
        return;
      }

      const target = parsePublicHttpUrl(targetRaw);

      const started = Date.now();
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 12000);
      const response = await fetchPublicHttpUrl(target.toString(), {
        maxRedirects: 0,
        signal: controller.signal,
        headers: {
          "user-agent":
            "SEOXBot/1.0 (+https://seox.local/crawler; compatible; site-audit)",
          accept:
            "text/html,application/xhtml+xml,application/xml;q=0.9,text/plain;q=0.8,*/*;q=0.5",
        },
      }).finally(() => clearTimeout(timeout));

      const contentType = response.headers.get("content-type") || "unknown";
      const location = response.headers.get("location");
      const bytes = Buffer.from(await response.arrayBuffer());
      const text = isTextContent(contentType)
        ? bytes.toString("utf8").slice(0, 2_000_000)
        : "";
      const finalUrl = response.url || target.toString();
      const parsed = parseCrawlText(text, contentType, finalUrl);
      if (location) {
        parsed.links = [
          ...new Set([
            ...(parsed.links || []),
            resolveUrl(location, finalUrl),
          ].filter(Boolean)),
        ];
      }

      sendJson(res, 200, {
        url: target.toString(),
        finalUrl,
        status: response.status,
        contentType,
        redirectedTo: location ? resolveUrl(location, finalUrl) : null,
        xRobotsTag: response.headers.get("x-robots-tag") || "",
        sizeKb: Math.round((bytes.length / 1024) * 10) / 10,
        loadTime: Date.now() - started,
        ...parsed,
      });
    } catch (error) {
      const status = error?.name === "AbortError" ? 504 : error?.status || 500;
      sendJson(res, status, {
        error:
          error?.name === "AbortError"
            ? "Crawl request timed out"
            : error?.message || "Crawl request failed",
      });
    }
  });
}

function isTextContent(contentType = "") {
  const lowered = contentType.toLowerCase();
  return TEXT_TYPES.some((type) => lowered.includes(type));
}

function parseCrawlText(text, contentType, baseUrl) {
  const lowered = contentType.toLowerCase();
  if (!text) return { links: [], resources: [], sitemaps: [], disallow: [] };
  if (lowered.includes("xml")) {
    return {
      links: extractSitemapLocs(text, baseUrl),
      resources: [],
      sitemaps: [],
      disallow: [],
    };
  }
  if (baseUrl.endsWith("/robots.txt") || lowered.includes("text/plain")) {
    const robots = parseRobots(text, baseUrl);
    return {
      links: [],
      resources: [],
      sitemaps: robots.sitemaps,
      disallow: robots.disallow,
    };
  }
  return parseHtml(text, baseUrl);
}

function parseHtml(html, baseUrl) {
  const links = new Set();
  const resources = new Set();

  for (const href of matchAttributes(html, "a", "href")) {
    addResolved(links, href, baseUrl);
  }
  for (const href of matchAttributes(html, "link", "href")) {
    addResolved(resources, href, baseUrl);
  }
  for (const src of matchAttributes(html, "script", "src")) {
    addResolved(resources, src, baseUrl);
  }
  for (const src of matchAttributes(html, "img", "src")) {
    addResolved(resources, src, baseUrl);
  }
  for (const srcset of matchAttributes(html, "source", "srcset")) {
    for (const src of parseSrcSet(srcset)) addResolved(resources, src, baseUrl);
  }
  for (const srcset of matchAttributes(html, "img", "srcset")) {
    for (const src of parseSrcSet(srcset)) addResolved(resources, src, baseUrl);
  }

  return {
    links: Array.from(links),
    resources: Array.from(resources),
    sitemaps: [],
    disallow: [],
    audit: extractHtmlAudit(html, baseUrl, {
      links: Array.from(links),
      resources: Array.from(resources),
    }),
  };
}

function extractHtmlAudit(html, baseUrl, discovered) {
  const titleTags = matchTags(html, "title").map((tag) => stripTags(tag));
  const h1Tags = matchTags(html, "h1").map((tag) => stripTags(tag));
  const metaTags = matchTagBlocks(html, "meta").map(parseAttributes);
  const linkTags = matchTagBlocks(html, "link").map(parseAttributes);
  const imgTags = matchTagBlocks(html, "img").map(parseAttributes);
  const canonical = linkTags.find((attrs) =>
    String(attrs.rel || "").toLowerCase().split(/\s+/).includes("canonical")
  );
  const robotsMeta = metaTags
    .filter((attrs) => String(attrs.name || "").toLowerCase() === "robots")
    .map((attrs) => String(attrs.content || "").toLowerCase())
    .join(", ");
  const descriptions = metaTags.filter((attrs) =>
    ["description", "og:description", "twitter:description"].includes(
      String(attrs.name || attrs.property || "").toLowerCase()
    )
  );
  const metaDescriptions = metaTags.filter((attrs) =>
    String(attrs.name || "").toLowerCase() === "description"
  );
  const ogTags = Object.fromEntries(
    metaTags
      .filter((attrs) => String(attrs.property || attrs.name || "").toLowerCase().startsWith("og:"))
      .map((attrs) => [String(attrs.property || attrs.name).toLowerCase(), attrs.content || ""])
  );
  const twitterTags = Object.fromEntries(
    metaTags
      .filter((attrs) => String(attrs.name || attrs.property || "").toLowerCase().startsWith("twitter:"))
      .map((attrs) => [String(attrs.name || attrs.property).toLowerCase(), attrs.content || ""])
  );
  const isHttps = baseUrl.startsWith("https:");
  const allDiscovered = [...discovered.links, ...discovered.resources];
  const httpUrls = allDiscovered.filter((url) => url.startsWith("http://"));
  const imageHttpUrls = imgTags
    .map((attrs) => attrs.src)
    .filter((src) => src && resolveUrl(src, baseUrl)?.startsWith("http://"));
  const metaRefresh = matchTagBlocks(html, "meta").find((tag) =>
    /http-equiv\s*=\s*["']?refresh/i.test(tag)
  );

  return {
    titleCount: titleTags.length,
    titleText: titleTags[0] || "",
    titleLength: (titleTags[0] || "").length,
    h1Count: h1Tags.length,
    h1Text: h1Tags[0] || "",
    metaDescriptionCount: metaDescriptions.length,
    metaDescriptionText: metaDescriptions[0]?.content || "",
    metaDescriptionLength: (metaDescriptions[0]?.content || "").length,
    anyDescriptionCount: descriptions.length,
    canonicalUrl: canonical?.href ? resolveUrl(canonical.href, baseUrl) : "",
    robotsMeta,
    noindex: /\bnoindex\b/i.test(robotsMeta),
    nofollow: /\bnofollow\b/i.test(robotsMeta),
    ogTags,
    twitterTags,
    ogMissingCount: countMissing(ogTags, ["og:title", "og:type", "og:image", "og:url", "og:description"]),
    twitterMissingCount: countMissing(twitterTags, ["twitter:card", "twitter:title", "twitter:description", "twitter:image"]),
    ogMissingAll: Object.keys(ogTags).length === 0,
    twitterMissingAll: Object.keys(twitterTags).length === 0,
    imageCount: imgTags.length,
    missingImageAltCount: imgTags.filter((attrs) => !String(attrs.alt || "").trim()).length,
    mixedContentCount: isHttps ? httpUrls.length : 0,
    httpImageCount: isHttps ? imageHttpUrls.length : 0,
    metaRefreshRedirect: Boolean(metaRefresh),
    linksCount: discovered.links.length,
    wordCount: stripTags(html).split(/\s+/).filter(Boolean).length,
  };
}

function matchAttributes(html, tag, attr) {
  const matches = [];
  const tagRe = new RegExp(`<${tag}\\b[^>]*>`, "gi");
  const attrRe = new RegExp(`${attr}\\s*=\\s*([\"'])(.*?)\\1`, "i");
  for (const tagMatch of html.matchAll(tagRe)) {
    const attrMatch = tagMatch[0].match(attrRe);
    if (attrMatch?.[2]) matches.push(decodeHtml(attrMatch[2].trim()));
  }
  return matches;
}

function matchTags(html, tag) {
  const re = new RegExp(`<${tag}\\b[^>]*>[\\s\\S]*?<\\/${tag}>`, "gi");
  return Array.from(html.matchAll(re), (match) => match[0]);
}

function matchTagBlocks(html, tag) {
  const re = new RegExp(`<${tag}\\b[^>]*>`, "gi");
  return Array.from(html.matchAll(re), (match) => match[0]);
}

function parseAttributes(tag) {
  const attrs = {};
  const attrRe = /([a-zA-Z_:][-a-zA-Z0-9_:.]*)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'=<>`]+))/g;
  for (const match of tag.matchAll(attrRe)) {
    attrs[match[1].toLowerCase()] = decodeHtml(match[2] || match[3] || match[4] || "");
  }
  return attrs;
}

function stripTags(value) {
  return decodeHtml(String(value).replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim());
}

function countMissing(source, keys) {
  return keys.filter((key) => !String(source[key] || "").trim()).length;
}

function parseSrcSet(srcset) {
  return String(srcset)
    .split(",")
    .map((part) => part.trim().split(/\s+/)[0])
    .filter(Boolean);
}

function extractSitemapLocs(xml, baseUrl) {
  const urls = new Set();
  for (const match of xml.matchAll(/<loc[^>]*>\s*([^<]+)\s*<\/loc>/gi)) {
    addResolved(urls, decodeHtml(match[1].trim()), baseUrl);
  }
  return Array.from(urls);
}

function parseRobots(text, baseUrl) {
  const sitemaps = new Set();
  const disallow = new Set();

  for (const rawLine of text.split(/\r?\n/)) {
    const line = rawLine.replace(/#.*/, "").trim();
    const sitemap = line.match(/^sitemap:\s*(.+)$/i);
    if (sitemap) addResolved(sitemaps, sitemap[1].trim(), baseUrl);

    const blocked = line.match(/^disallow:\s*(.+)$/i);
    if (blocked && blocked[1].trim()) disallow.add(blocked[1].trim());
  }

  return { sitemaps: Array.from(sitemaps), disallow: Array.from(disallow) };
}

function addResolved(set, value, baseUrl) {
  if (!value || /^(mailto:|tel:|javascript:|data:|blob:)/i.test(value)) return;
  const resolved = resolveUrl(value, baseUrl);
  if (resolved) set.add(resolved);
}

function resolveUrl(value, baseUrl) {
  if (!value || /^(mailto:|tel:|javascript:|data:|blob:)/i.test(value)) return "";
  try {
    const url = new URL(value, baseUrl);
    url.hash = "";
    return url.toString();
  } catch {
    return "";
  }
}

function decodeHtml(value) {
  return String(value)
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, "\"")
    .replace(/&#39;/g, "'");
}

async function createWebRequest(req, mountPath) {
  const headers = new Headers();
  Object.entries(req.headers || {}).forEach(([key, value]) => {
    if (Array.isArray(value)) headers.set(key, value.join(", "));
    else if (value !== undefined) headers.set(key, String(value));
  });

  const method = req.method || "GET";
  const init = { method, headers };
  if (!["GET", "HEAD"].includes(method)) {
    init.body = await readRawBody(req);
  }

  return new Request(mountedUrl(req, mountPath), init);
}

function createNodeJsonResponse(res) {
  return {
    setHeader(name, value) {
      res.setHeader(name, value);
      return this;
    },
    status(statusCode) {
      res.statusCode = statusCode;
      return this;
    },
    json(payload) {
      res.setHeader("content-type", "application/json; charset=utf-8");
      res.end(JSON.stringify(payload));
      return this;
    },
    end(payload) {
      res.end(payload);
      return this;
    },
  };
}

async function sendWebResponse(res, response) {
  res.statusCode = response.status;
  response.headers.forEach((value, key) => {
    res.setHeader(key, value);
  });
  res.end(Buffer.from(await response.arrayBuffer()));
}

function sendJson(res, status, payload) {
  res.statusCode = status;
  res.setHeader("content-type", "application/json; charset=utf-8");
  res.end(JSON.stringify(payload));
}

export default defineConfig({
  plugins: [react(), proxyApiPlugin(), deepseekApiPlugin(), deepseekSettingsApiPlugin(), fetchUrlMetaApiPlugin(), pagespeedApiPlugin(), speedApiPlugin(), wordpressSecurityApiPlugin(), screamingFrogApiPlugin(), webmasterApiPlugin(), autocompleteApiPlugin(), gscTokenApiPlugin(), gbpApiPlugin(), jiraApiPlugin(), projectsApiPlugin(), projectDetailsApiPlugin(), settingsApiPlugin(), backlinksAnalyzeApiPlugin(), w3cValidationApiPlugin(), expiredDomainsCheckApiPlugin(), backlinkCleanerApiPlugin(), backlinkIndexerApiPlugin(), keywordResearchApiPlugin(), ubersuggestApiPlugin(), authApiPlugin(), contentOutlineApiPlugin(), entitiesExtractorApiPlugin(), entitiesGeneratorApiPlugin(), contentNgramsApiPlugin(), contentNlpApiPlugin(), contentGrammarApiPlugin(), contentUniqueNgramsApiPlugin(), contentSkipGramApiPlugin(), contentOptimizationApiPlugin(), contentWatermarkRemoverApiPlugin(), contentSemanticGeneratorApiPlugin(), contentAnalyzerApiPlugin(), aiHelperApiPlugin(), textEditorApiPlugin(), domainSeparatorApiPlugin(), wordCounterApiPlugin(), botViewerApiPlugin(), daPaCheckerApiPlugin(), metaExtractorApiPlugin(), sitemapExtractorApiPlugin(), seoToolsApiPlugin(), promptTrackingApiPlugin(), brandSentimentApiPlugin(), citationFlowApiPlugin(), competitorResearchApiPlugin(), internalLinksApiPlugin(), aiChatApiPlugin(), llmsGeneratorApiPlugin(), aiModelCheckerApiPlugin(), aiCompatibilityApiPlugin(), semanticWriterEditorApiPlugin(), contentWriterApiPlugin(), auditorApiPlugin(), crawlerApiPlugin()],
  server: {
    port: 3000,
    host: true,
  },
  preview: {
    host: true,
    port: 4173,
  },
  build: {
    // The eager payload is the entry chunk plus the small shared chunks it
    // statically imports. Anything much over this means something that should
    // be lazy became eager again.
    chunkSizeWarningLimit: 600,
    rollupOptions: {
      output: {
        // Only the framework and the heavy third-party libraries are grouped
        // by hand. Application code is left to Rolldown, which already splits
        // one chunk per lazy() route and lifts genuinely shared modules into
        // their own chunks.
        //
        // Grouping application code by feature section was tried and reverted:
        // the groups absorbed shared modules out of the common chunks, which
        // put nine feature chunks back into the entry graph and pushed the
        // eager payload to 1.8 MB. Measured, not assumed - see
        // PERFORMANCE_UPGRADE_PLAN.md section 9.
        codeSplitting: {
          groups: [
            {
              name: 'vendor-react',
              test: /[\/]node_modules[\/](react|react-dom|scheduler|react-router|react-router-dom)[\/]/,
              priority: 100,
            },
            { name: 'vendor-charts', test: /[\/]node_modules[\/](recharts|d3-[a-z]+|victory-vendor)[\/]/, priority: 90 },
            { name: 'vendor-maps', test: /[\/]node_modules[\/](leaflet|react-leaflet|@react-leaflet)[\/]/, priority: 90 },
            { name: 'vendor-pdf', test: /[\/]node_modules[\/](jspdf|jspdf-autotable|html2canvas)[\/]/, priority: 90 },
            { name: 'vendor-motion', test: /[\/]node_modules[\/]framer-motion[\/]/, priority: 90 },
          ],
        },
      },
    },
  },
});
